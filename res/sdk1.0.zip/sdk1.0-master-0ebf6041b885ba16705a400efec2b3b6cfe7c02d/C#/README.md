SDK to integrate Logitech's Craft smart keyboard support into your C# application
