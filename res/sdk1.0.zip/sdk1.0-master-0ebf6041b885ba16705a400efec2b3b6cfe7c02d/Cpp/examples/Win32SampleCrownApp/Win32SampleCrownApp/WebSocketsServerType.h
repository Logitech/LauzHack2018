//
//  WebSocketsServerType.h
//  plugin_manager
//
//  Created by Christian Gavin on 3/13/17.
//
//

#pragma once

//typedef websocketpp::client<websocketpp::config::asio> Client;
