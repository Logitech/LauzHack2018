SDK to integrate Logitech's Craft smart keyboard support into your C++ application

Examples
=

name | description
-|-
**echo_client** | Writes to stdout websocket response messages received from the plugin_manager.
**breakout** | C++/OpenGL implementation of the classic arcade game *Breakout*.


breakout
=

This is a C++/OpenGL implementation of the game *Breakout*, modified to support the Crown.
The original source can be obtained from GitHub at https://github.com/wiranoid/breakout.git.

The source has been verified to work with **Visual Studio 2017**.

The Crown Handler implementation in **breakout/src/craftplugin/CrownHandler.cpp** requires small modification (obtain process ID and process name) to work with Xcode.

**CrownHandler.cpp**
```c++
void onOpen(std::shared_ptr<client> c, websocketpp::connection_hdl hdl)
{
    std::cout << "onOpen called with hdl: " << hdl.lock().get() << std::endl;

    websocketpp::lib::error_code ec;

    // Send plugin registration message
    Json::Value json;
    json["message_type"] = "register";
    json["plugin_guid"] = PluginGuid;
    json["PID"] = (unsigned int)GetCurrentProcessId();
    json["execName"] = "breakout.exe";

    c->send(hdl, Json::FastWriter().write(json), websocketpp::frame::opcode::value::text, ec);
    if (ec)
    {
        std::cout << "Plugin registration failed because: " << ec.message() << std::endl;
    }
}
```

**Replace GetCurrentProcessID() and "breakout.exe"**
```c++
    json["PID"] = (unsigned int)GetCurrentProcessId();
    json["execName"] = "breakout.exe";
```

There may be other areas in the CrownHandler.cpp to modify in order to make it build from Xcode.